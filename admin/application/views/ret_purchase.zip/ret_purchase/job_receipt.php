<html>
	<head>
		<meta charset="utf-8">
		
		<title>Job Receipt - <?php echo $order['pur_no'];?> </title>
		
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/job_receipt.css">

	</head>
	<body>
		<div class="PDFReceipt">

			<div class="heading">
				<div class="company_name"><?php echo $comp_details['company_name']; ?></div>
				<div><?php echo $comp_details['address1'] ?> , <?php echo $comp_details['city'] ?></div>
				<div>GST No : <?php echo $comp_details['gst_number'] ?></div>
				<div>State Name : <?php echo $comp_details['state'] ?>, Code : <?php echo $comp_details['state_code'] ?></div>
			</div>

			<div class="karigar_details">

				<div class="details_left">
					<div class="receipt_from">Receipt From</div>
					
					<div><?php echo $po_item['karigar_name']; ?> - <?php echo $po_item['contactno1'] != '' ? $po_item['contactno1'] : $po_item['contactno2']; ?></div>
					<div><?php echo $po_item['address1']; ?></div>
					<div><?php echo $po_item['address2']; ?></div>
					<div><?php echo $po_item['address3']; ?></div>
					<div><?php echo $po_item['city_name']; ?></div>
					<div><?php echo $po_item['state_name']; ?></div>
					<div><?php echo $po_item['country_name']; ?> - <?php echo $po_item['pincode']; ?></div>
				</div>

				<div class="print_title">
					Job Work Receipt
				</div>

				<div class="details_right">
					<div>Date &nbsp;&nbsp; : &nbsp;&nbsp;&nbsp; <?php echo $po_item['po_date']; ?></div>

					<div>Job Receipt Number &nbsp;&nbsp; : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $po_item['po_ref_no']; ?></div>
				</div>

			</div>


			<div class="receipt_details">
				<table class="job_receipt_table">
					<tbody>
						<tr>
							<th class="alignLeft">S.No</th>
							<th class="alignLeft">HSN Code</th>
							<th class="alignLeft">Description Of Goods</th>
							<th class="alignRight">Pcs</th>
							<th class="alignRight">Purity</th>
							<th class="alignRight">Gwt</th>
							<th class="alignRight">Nwt</th>
							<th class="alignRight">VA(Gm)</th>
							<th class="alignRight">MC</th>
						</tr>
					</tbody>
					<tbody>
						<?php
							$i = 1;
							$total_pcs = 0;
							$total_gwt = 0;
							$total_wastage = 0;
							$total_mc = 0;

							foreach($po_item_details as $po_detail) { ?>

								<?php 
								
								$total_pcs = $total_pcs + $po_detail['no_of_pcs'];

								$total_gwt = $total_gwt + $po_detail['gross_wt'];
								
								$making_charge = round($po_detail['mc_type'] == 2 ? $po_detail['mc_value'] * $po_detail['gross_wt'] : $po_detail['mc_value'] * 1,3); 

								$total_mc = $total_mc + $making_charge;
								
								$wastage = round(($po_detail['gross_wt'] / 100) * $po_detail['item_wastage'],3);
								
								$total_wastage = $total_wastage + $wastage;
								?>

								<tr>

									<td class="alignLeft"><?php echo $i ?></td>

									<td class="alignLeft"><?php echo $po_detail['hsn_code'] ?></td>

									<td class="alignLeft"><?php echo $po_detail['product_name'] ?></td>

									<td class="alignRight"><?php echo $po_detail['no_of_pcs'] ?></td>

									<td class="alignRight"><?php echo $po_item['purity'] ?></td>

									<td class="alignRight"><?php echo $po_detail['gross_wt'] ?></td>

									<td class="alignRight"><?php echo $po_detail['net_wt'] ?></td>

									<td class="alignRight"><?php echo $wastage ?></td>

									<td class="alignRight"><?php echo $making_charge; ?></td>

								</tr>

						<?php }	?>

					</tbody>
					<tfoot>
						<tr>
							<td class="alignCenter" colspan="3">Total</td>
							<td class="alignRight"><?php echo $total_pcs ?></td>
							<td></td>
							<td class="alignRight"><?php echo number_format((float)$total_gwt, 3, '.', ''); ?></td>
							<td></td>
							<td class="alignRight"><?php echo number_format((float)$total_wastage, 3, '.', ''); ?></td>
							<td class="alignRight"><?php echo number_format((float)$total_mc, 3, '.', ''); ?></td>
						</tr>
					</tfoot>
				</table>
			</div>
			
			<div class="footer">

				<div class="footer_left">
					Checked By
				</div>

				<div class="footer_center">
					Verified By
				</div>

				<div class="footer_right">
					Authorised Signatory
				</div>
			</div>
			
		</div>
		
		<script type="text/javascript">

			setTimeout(function(){
			
				window.print();
			
			}, 1000);

		</script>

	</body>
</html>