      <!-- Content Wrapper. Contains page content -->
    <style>
    	.remove-btn{
			margin-top: -168px;
		    margin-left: -38px;
		    background-color: #e51712 !important;
		    border: none;
		    color: white !important;
		}
		.sm{
			font-weight: normal;
		}
		}
    </style>
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
       

        <!-- Main content -->
        <section class="content order">

          <!-- Default box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">PURCHASE ORDER</h3>
            </div>
            <div class="box-body">
             <!-- form container --> 
	             <!-- form -->
				<form id="order_submit">
				<div class="row">
				    <div class="col-md-12">
				        <div class="col-md-4">
    	                     <div class="form-group">
    	                       <label>Order For<span class="error">*</span></label></br>
    	                            <input type="radio" id="stock_order" name="order[order_for]" value="1" checked> <label for="stock_order" class="custom-label"> Stock Order </label>
    	                            <input type="radio" id="cus_order" name="order[order_for]" value="2" > <label for="cus_order" class="custom-label"> Customer Order </label>
    	                            <input type="radio" id="stock_repair_order" name="order[order_for]" value="3" > <label for="stock_repair_order" class="custom-label"> Stock Repair Order </label>
    	                     </div> 
    			        </div>
				        <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Select Karigar<span class="error">*</span></label>
    								<select id="select_karigar" class="form-control" name="order[id_karigar]" style="width:100%;" tabindex="1">></select>
    	                     </div> 
				        </div>
				        
				        <div class="col-md-2 stock_repair" style="display:none;">
    	                     <div class="form-group">
    	                       <label>Select Branch<span class="error">*</span></label>
    								<select id="branch_select" class="form-control" name="order[id_branch]" style="width:100%;" tabindex="1" disabled></select>
    								<input id="id_branch" name="lt_item[id_branch]" type="hidden" value="<?php echo set_value('po_item[id_branch]',$po_item['id_branch']); ?>" />
    	                     </div> 
				        </div>
				        
				        <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Due Date<span class="error">*</span></label> 
    							<input class="form-control datemask date smith_due_dt" name="order[smith_due_dt]" placeholder="Select Due Date" data-date-format="dd-mm-yyyy" type="text" tabindex="2"/>
    	                     </div> 
    			        </div>
				        
    			        <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Customer Order No<span class="error">*</span></label>
    								<select id="select_order_no" name="order[id_customer_order]" class="form-control"  style="width:100%;" tabindex="3" disabled></select>
    	                     </div> 
    	                     
    			        </div>
    			        
    			        <div class="col-md-2 stock_and_cus_ord">
    	                     <div class="form-group"></br>
    	                       <button type="button" id="add_image" class="btn btn-primary" >Add Image</button>
    	                       <input type="hidden" id="order_iamges">
    			        </div>
    			        
    			     </div>
    			 </div>
    			 <div class="row stock_and_cus_ord">
    			     <div class="col-md-12">
    			        <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Select Product<span class="error">*</span></label>
    								<select id="select_product" class="form-control"  style="width:100%;" tabindex="4"></select>
    	                     </div> 
    			        </div>
    			        
    			         <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Select Design<span class="error">*</span></label>
    								<select id="select_design" class="form-control"  style="width:100%;" tabindex="5"></select>
    	                     </div> 
    			        </div>
    			         <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Sub Design<span class="error">*</span></label>
    								<select id="select_sub_design" class="form-control"  style="width:100%;" tabindex="6"></select>
    	                     </div> 
    			        </div>
    			        
    			        <div class="col-md-2 stock_order">
    	                     <div class="form-group">
    	                       <label>Select Weight Range<span class="error">*</span></label>
    								<select id="select_weight_range" class="form-control"  style="width:100%;" tabindex="7"></select>
    	                     </div> 
    			        </div>
    			        
    			        <div class="col-md-2 customer_order" style="display:none;">
    	                     <div class="form-group">
    	                       <label>Weight<span class="error">*</span></label>
    								<input id="order_weight" class="form-control"  style="width:100%;" tabindex="7"></select>
    	                     </div> 
    			        </div>
    			        
    			        <div class="col-md-2 stock_order">
    	                     <div class="form-group">
    	                       <label>Select Size</label>
    								<select id="select_size" class="form-control"  style="width:100%;" tabindex="8"></select>
    	                     </div> 
    			        </div>
    			        
    			        <div class="col-md-2">
    	                     <div class="form-group">
    	                       <label>Pcs<span class="error">*</span></label>
    							<input type="number" class="form-control" id="tot_pcs" tabindex="9">
    	                     </div> 
    			        </div>
    			        
				    </div>
				</div>	
				<div class="row">
				    <div class="col-md-12">
				        <div class="col-sm-10">
				 			<div class="form-group">
					 			<div class="input-group">
					 			    <label>Note</label>
					 				<textarea class="form-control" id="remark" rows="5" cols="100"> </textarea>
								</div>
							</div>
				 		</div>
				    </div>
				</div>
				
				
				<div class="row">
				    <div class="col-sm-12" align="center">
						<button type="button" id="add_order_item" class="btn btn-primary">Add Item</button> 
						<button type="button" class="btn btn-default btn-cancel">Cancel</button>
				    </div>
				</div>
        									
			
				 
				<div class="row">
					<div class="col-md-12">
					    <div class="table-responsive">
						<p class="help-block"></p></legend>
						 <table id="item_detail" class="table table-bordered table-striped">
							<thead>
						          <tr>
						            <th width="15%;">Product</th> 
						            <th width="15%;">Design</th> 
						            <th width="15%;">Sub Design</th> 
						            <th width="10%;">Size</th> 
						            <th width="10%;">Wgt Range</th> 
						            <th width="10%;">Approx Wt</th> 
						            <th width="10%;">Pcs</th> 
						            <th width="10%;">Due Date</th> 
						            <th width="10%;">Action</th> 
						          </tr>
					         </thead>
					         <tbody> 
					         </tbody>
					         <tfoot>
					             <tr style="font-weight:bold;">
					                 <td colspan="5">Total</td>
					                 <td><input type="hidden" class="order_wt" id="order_wt" name="order[order_wt]"><span class="tot_wt"></span></td>
					                 <td><input type="hidden" class="order_pcs" id="order_pcs" name="order[order_pcs]"><span class="tot_pcs"></span></td>
					                 <td></td>
					                 <td></td>
					             </tr>
					         </tfoot>
						</table>
					    </div>
					</div> 
				</div>	
				<p class="help-block"></p>
			
				
				<div class="row">
				    <div class="col-sm-12" align="center">
						<button type="button" id="create_order" class="btn btn-primary">save</button> 
						<button type="button" class="btn btn-default btn-cancel">Cancel</button>
				    </div>
				</div>
			
	           </div>  
	            <?php echo form_close();?>
	           
	       </div>  
	       <div class="overlay" style="display:none">
				  <i class="fa fa-refresh fa-spin"></i>
				</div>
        </section>
    </div>
    

<!--  Image Upload-->
<div class="modal fade" id="imageModal_new" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="width:60%;">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">Add Image</h4>
			</div>
			<div class="modal-body" style="height: 200px;">
        <div class="ord_img">
            Add Image
            <input id="order_images_new" class="order_images_new" name="order_images_new" accept="image/*" type="file" multiple="true">
        </div>
        <br>
         <div id="order_images" style="margin-top: 2%;"></div>
			</div>
			
		  <div class="modal-footer">
			<button type="button" id="update_img_new" class="btn btn-success">Save</button>
			<button type="button" id="close_stone_details_new" class="btn btn-warning" data-dismiss="modal">Close</button>
		  </div>
		</div>
	</div>
</div>
</div>
            
