<!-- Content Wrapper. Contains page content -->
    
  <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Supplier Contract  Report
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Reports</a></li>
            <li class="active">Supplier contract Report</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
               
               <div class="box box-primary">
                 <div class="box-body">  
				   	<div class="box box-info stock_details">
						<div class="box-header with-border">
						  <div class="row">
							
                                <div class="col-md-2"> 
									<label>Select Karigar</label>
									<select id="karigar" class="form-control" style="width:100%;"></select>
								</div>
								<div class="col-md-2"> 
									<label>Select Status</label>
									<select id="price_status" class="form-control" style="width:100%;">
									    <option value="">Select Type</option>
									    <option value="0">Yet to Approved</option>
									    <option value="1">Approved</option>
									    <option value="2">Rejected</option>
									</select>
								</div>
								<div class="col-md-2"> 
									<label></label>
									<div class="form-group">
										<button type="button" id="supplier_contract_search" class="btn btn-info">Search</button>   
									</div>
								</div>
							</div>
							
						</div>
						<div class="box-body">
							<div class="row">
								<div class="box-body">
								   <div class="table-responsive">
									  <table id="supplier_contract_list" class="table table-bordered table-striped text-center">
										 <thead>
		                    
							  <tr>
	                            <th width="10%">#</th>   
								<th width="10%">Name</th>   
	                            <th width="10%">Created Date</th>
	                            <th width="10%">Approved Date</th>
	                            <th width="10%">Product</th>  
		                        <th width="10%">Design</th>  
	                            <th width="10%">Sub Design</th> 
	                            <th width="10%">MC Type</th> 
	                            <th width="10%">MC Value</th> 
	                            <th width="10%">Touch</th> 
	                            <th width="10%">V.A(%)</th>  
		                        <th width="10%">Status</th>  
	                            <th width="10%">Created By</th> 
	                            <th width="10%">Approved By</th> 
							  </tr>
		                    </thead> 
		                    <tbody>

                            </tbody>
									 </table>
								  </div>
								</div> 
							</div> 
						</div>
					</div>
                </div>
                <div class="overlay" style="display:none">
				  <i class="fa fa-refresh fa-spin"></i>
				</div>
              </div>
            </div>
          </div>
        </section>
</div>